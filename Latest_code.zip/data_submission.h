#ifndef DATA_SUBMISSION_H
#define DATA_SUBMISSION_H

void anedya_submitData(String datapoint, float sensor_data);

#endif 