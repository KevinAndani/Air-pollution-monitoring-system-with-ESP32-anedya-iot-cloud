#ifndef X_WIFI_H_
#define X_WIFI_H_

#include <WiFi.h>

extern const char *ssid;
extern const char *pass;

void initWiFi();

#endif // WIFI_H_