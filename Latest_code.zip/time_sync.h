#ifndef TIME_SYNC_H
#define TIME_SYNC_H

#include <ArduinoJson.h>
#include <TimeLib.h>

extern String timeRes;

void setDeviceTime();

#endif // TIME_SYNC_H